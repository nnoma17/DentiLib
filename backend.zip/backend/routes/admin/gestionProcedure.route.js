const express = require("express");
const {
    createProcedure,
    deleteProcedure,
    modifyProcedure,
    getAllProcedures
} = require("../../controllers/admin/gestionProcedure.controller");
const authMiddleware = require("../../middleware/authMiddleware");

const router = express.Router();
router.post('/admin/gestionProcedure/create_Procedure', authMiddleware, createProcedure);
router.put('/admin/gestionProcedure/modify_Procedure/:procedureId', authMiddleware, modifyProcedure);
router.get('/admin/gestionProcedure/get_All_Procedures', authMiddleware, getAllProcedures);
router.delete("/admin/gestionProcedure/delete_Procedure/:procedureId",authMiddleware, deleteProcedure);

module.exports = router;